This folder is populated with Prototype.unity automatically by ProjectSetup.cs when the project is opened in Unity Editor. If needed, use Tools > Blocklands > Create Prototype Scene.
