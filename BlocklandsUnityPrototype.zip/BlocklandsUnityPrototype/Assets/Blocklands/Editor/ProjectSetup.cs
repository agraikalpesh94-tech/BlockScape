#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Blocklands;
using System.IO;

[InitializeOnLoad]
public static class ProjectSetup
{
    const string ScenePath = "Assets/Blocklands/Scenes/Prototype.unity";
    static ProjectSetup()
    {
        EditorApplication.delayCall += () =>
        {
            if (!File.Exists(ScenePath)) CreateScene();
        };
    }

    [MenuItem("Tools/Blocklands/Create Prototype Scene")]
    public static void CreateScene()
    {
        Directory.CreateDirectory("Assets/Blocklands/Scenes");
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        var worldObj = new GameObject("Voxel World");
        worldObj.AddComponent<VoxelWorld>();

        var player = new GameObject("Player");
        player.tag = "Player";
        player.transform.position = new Vector3(0, 12, -4);
        var cc = player.AddComponent<CharacterController>();
        cc.height = 1.8f; cc.radius = .32f; cc.center = new Vector3(0,.9f,0);
        var camObj = new GameObject("Player Camera");
        camObj.transform.SetParent(player.transform, false);
        camObj.transform.localPosition = new Vector3(0,1.55f,0);
        var cam = camObj.AddComponent<Camera>();
        cam.fieldOfView = 78;
        cam.nearClipPlane = .05f;
        camObj.AddComponent<AudioListener>();
        var pc = player.AddComponent<PlayerController>();
        pc.playerCamera = cam;

        var sunObj = new GameObject("Sun");
        var sun = sunObj.AddComponent<Light>();
        sun.type = LightType.Directional;
        sun.intensity = 1.1f;
        sun.shadows = LightShadows.Soft;
        sunObj.transform.rotation = Quaternion.Euler(50, -30, 0);
        var cycle = sunObj.AddComponent<DayNightCycle>();
        cycle.sun = sun;

        var hud = new GameObject("Game HUD");
        hud.AddComponent<GameHUD>();

        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
        RenderSettings.ambientLight = new Color(.5f,.5f,.5f);
        RenderSettings.fog = true;
        RenderSettings.fogColor = new Color(.55f,.72f,.85f);
        RenderSettings.fogMode = FogMode.ExponentialSquared;
        RenderSettings.fogDensity = .008f;

        EditorSceneManager.SaveScene(scene, ScenePath);
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
        AssetDatabase.SaveAssets();
        Debug.Log("Blocklands prototype scene created.");
    }
}
#endif
