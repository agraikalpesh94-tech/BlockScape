using UnityEngine;

namespace Blocklands
{
    public class DayNightCycle : MonoBehaviour
    {
        public Light sun;
        public float cycleSeconds=240f;
        float timer=70f;

        void Update()
        {
            if(!sun) return;
            timer += Time.deltaTime / cycleSeconds * 360f;
            if(timer>=360f) timer-=360f;
            sun.transform.rotation=Quaternion.Euler(timer-90f,35f,0);
            float daylight=Mathf.Clamp01(Mathf.Sin(timer*Mathf.Deg2Rad)*1.15f+.15f);
            sun.intensity=Mathf.Lerp(.08f,1.15f,daylight);
            RenderSettings.ambientLight=Color.Lerp(new Color(.035f,.05f,.12f),new Color(.55f,.58f,.62f),daylight);
            Camera cam=Camera.main;
            if(cam) cam.backgroundColor=Color.Lerp(new Color(.025f,.035f,.11f),new Color(.48f,.72f,.92f),daylight);
        }
    }
}
