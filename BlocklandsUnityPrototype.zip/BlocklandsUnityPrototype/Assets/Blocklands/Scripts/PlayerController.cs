using UnityEngine;

namespace Blocklands
{
    [RequireComponent(typeof(CharacterController))]
    public class PlayerController : MonoBehaviour
    {
        public float moveSpeed = 5f;
        public float lookSensitivity = .14f;
        public float gravity = -22f;
        public Camera playerCamera;
        CharacterController controller;
        float pitch;
        Vector2 moveInput;
        Vector2 lookInput;
        int lookFinger = -1;
        int moveFinger = -1;
        Vector2 moveOrigin;
        bool mouseLook;

        public Vector2 MoveInput { get => moveInput; set => moveInput = Vector2.ClampMagnitude(value,1f); }

        void Awake()
        {
            controller = GetComponent<CharacterController>();
            if (!playerCamera) playerCamera = GetComponentInChildren<Camera>();
        }

        void Update()
        {
            HandleTouch();
#if UNITY_EDITOR || UNITY_STANDALONE
            float mx = Input.GetAxis("Mouse X");
            float my = Input.GetAxis("Mouse Y");
            if (Input.GetMouseButtonDown(1)) mouseLook = true;
            if (Input.GetMouseButtonUp(1)) mouseLook = false;
            if (mouseLook) Look(new Vector2(mx,my));
            MoveInput = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
#endif
            transform.Rotate(Vector3.up, lookInput.x * lookSensitivity, Space.World);
            pitch = Mathf.Clamp(pitch - lookInput.y * lookSensitivity, -80f, 80f);
            if (playerCamera) playerCamera.transform.localRotation = Quaternion.Euler(pitch,0,0);
            lookInput = Vector2.zero;

            Vector3 move = transform.right * moveInput.x + transform.forward * moveInput.y;
            if (!controller.isGrounded) move.y += gravity * Time.deltaTime;
            else move.y = -1.5f;
            controller.Move(move * moveSpeed * Time.deltaTime);
        }

        void HandleTouch()
        {
            if (Input.touchCount == 0) { moveFinger=-1; lookFinger=-1; moveInput=Vector2.zero; return; }
            for(int i=0;i<Input.touchCount;i++)
            {
                Touch t=Input.GetTouch(i);
                if(t.phase==TouchPhase.Began)
                {
                    if(t.position.x < Screen.width*.43f && moveFinger==-1) { moveFinger=t.fingerId; moveOrigin=t.position; }
                    else if(lookFinger==-1) lookFinger=t.fingerId;
                }
                if(t.fingerId==moveFinger)
                {
                    if(t.phase==TouchPhase.Ended || t.phase==TouchPhase.Canceled) { moveFinger=-1; moveInput=Vector2.zero; }
                    else moveInput=Vector2.ClampMagnitude((t.position-moveOrigin)/85f,1f);
                }
                if(t.fingerId==lookFinger)
                {
                    if(t.phase==TouchPhase.Moved) Look(t.deltaPosition);
                    if(t.phase==TouchPhase.Ended || t.phase==TouchPhase.Canceled) lookFinger=-1;
                }
            }
        }

        void Look(Vector2 delta) { lookInput += delta; }
    }
}
