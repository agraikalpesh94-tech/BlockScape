using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace Blocklands
{
    public enum BlockType { Grass, Dirt, Stone, Sand, Wood, Leaves, Water }

    [Serializable] public class BlockEdit
    {
        public Vector3Int position;
        public int type; // -1 means removed
        public BlockEdit(Vector3Int p, int t) { position = p; type = t; }
    }

    public class VoxelWorld : MonoBehaviour
    {
        public int seed = 314159;
        public int chunkRadius = 2;
        public int chunkSize = 12;
        public int maxHeight = 14;
        public float blockSize = 1f;

        readonly Dictionary<Vector3Int, GameObject> blocks = new Dictionary<Vector3Int, GameObject>();
        readonly Dictionary<Vector2Int, GameObject> chunks = new Dictionary<Vector2Int, GameObject>();
        readonly Dictionary<Vector3Int, int> edits = new Dictionary<Vector3Int, int>();
        Material[] materials;
        Transform player;

        public int SelectedBlock { get; set; } = (int)BlockType.Dirt;

        void Awake()
        {
            CreateMaterials();
            GenerateWorld();
        }

        void Start()
        {
            var p = GameObject.FindWithTag("Player");
            if (p) player = p.transform;
        }

        void CreateMaterials()
        {
            materials = new Material[7];
            Color[] colors = {
                new Color(.25f,.58f,.20f), new Color(.40f,.25f,.13f), new Color(.42f,.44f,.46f),
                new Color(.78f,.70f,.48f), new Color(.38f,.23f,.11f), new Color(.16f,.42f,.12f),
                new Color(.15f,.42f,.78f,.65f)
            };
            for (int i=0;i<materials.Length;i++)
            {
                var m = new Material(Shader.Find("Standard"));
                m.color = colors[i];
                if (i == (int)BlockType.Water) { m.SetFloat("_Mode", 3); m.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha); m.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha); m.SetInt("_ZWrite", 0); m.EnableKeyword("_ALPHABLEND_ON"); m.renderQueue = 3000; }
                materials[i] = m;
            }
        }

        public void GenerateWorld()
        {
            UnityEngine.Random.InitState(seed);
            for (int cx=-chunkRadius; cx<=chunkRadius; cx++)
            for (int cz=-chunkRadius; cz<=chunkRadius; cz++)
            {
                var chunkRoot = new GameObject("Chunk_" + cx + "_" + cz);
                chunkRoot.transform.SetParent(transform, false);
                chunks[new Vector2Int(cx,cz)] = chunkRoot;
                for (int x=0; x<chunkSize; x++)
                for (int z=0; z<chunkSize; z++)
                {
                    int wx = cx*chunkSize+x, wz = cz*chunkSize+z;
                    float n = Mathf.PerlinNoise((wx+seed)*.055f, (wz-seed)*.055f);
                    float ridge = Mathf.PerlinNoise((wx+seed)*.018f, (wz+seed)*.018f);
                    int h = Mathf.Clamp(3 + Mathf.RoundToInt(n*5f + ridge*maxHeight*.35f), 2, maxHeight);
                    bool beach = h <= 4;
                    for (int y=0; y<=h; y++)
                    {
                        BlockType t = y==h ? (beach ? BlockType.Sand : BlockType.Grass) :
                            (y>h-3 ? (beach ? BlockType.Sand : BlockType.Dirt) : BlockType.Stone);
                        Vector3Int pos = new Vector3Int(wx,y,wz);
                        if (edits.TryGetValue(pos, out int edit)) { if (edit >= 0) AddBlock(pos,(BlockType)edit,chunkRoot.transform); }
                        else AddBlock(pos,t,chunkRoot.transform);
                    }
                    // Small stylized trees; kept sparse for phone performance.
                    if (!beach && h>5 && Mathf.PerlinNoise(wx*.31f+seed, wz*.31f-seed)>.83f)
                    {
                        for(int ty=1;ty<=3;ty++) AddBlock(new Vector3Int(wx,h+ty,wz),BlockType.Wood,chunkRoot.transform);
                        for(int lx=-2;lx<=2;lx++) for(int lz=-2;lz<=2;lz++) for(int ly=2;ly<=4;ly++)
                            if(Mathf.Abs(lx)+Mathf.Abs(lz)+(ly==4?1:0)<=4)
                                AddBlock(new Vector3Int(wx+lx,h+ly,wz+lz),BlockType.Leaves,chunkRoot.transform);
                    }
                }
            }
            // Simple water layer in low areas.
            var water = GameObject.CreatePrimitive(PrimitiveType.Cube);
            water.name = "WaterTable";
            water.transform.position = new Vector3(0, 2.15f, 0);
            water.transform.localScale = new Vector3(chunkRadius*chunkSize*2+chunkSize, .12f, chunkRadius*chunkSize*2+chunkSize);
            water.GetComponent<Renderer>().sharedMaterial = materials[(int)BlockType.Water];
            water.GetComponent<Collider>().enabled = false;
            water.transform.SetParent(transform, true);
        }

        void AddBlock(Vector3Int pos, BlockType type, Transform parent)
        {
            if (blocks.ContainsKey(pos)) return;
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = type.ToString();
            go.transform.position = new Vector3(pos.x,pos.y,pos.z);
            go.transform.localScale = Vector3.one * blockSize;
            go.GetComponent<Renderer>().sharedMaterial = materials[(int)type];
            go.transform.SetParent(parent, true);
            blocks[pos] = go;
        }

        public bool BreakBlock(Ray ray)
        {
            if (!Physics.Raycast(ray, out RaycastHit hit, 6f)) return false;
            var go = hit.collider.gameObject;
            if (!blocks.ContainsValue(go)) return false;
            Vector3Int p = Vector3Int.RoundToInt(go.transform.position);
            blocks.Remove(p); edits[p] = -1;
            Destroy(go);
            return true;
        }

        public bool PlaceBlock(Ray ray)
        {
            if (!Physics.Raycast(ray, out RaycastHit hit, 6f)) return false;
            Vector3Int p = Vector3Int.RoundToInt(hit.collider.transform.position + hit.normal * 1.01f);
            if (blocks.ContainsKey(p) || p.y < 0 || p.y > 80) return false;
            BlockType t = (BlockType)Mathf.Clamp(SelectedBlock, 0, 5);
            var parent = transform;
            AddBlock(p,t,parent);
            edits[p] = (int)t;
            return true;
        }

        [Serializable] class SaveData { public int seed; public List<BlockEdit> edits = new List<BlockEdit>(); }
        string SavePath => Path.Combine(Application.persistentDataPath, "blocklands_world.json");

        public void SaveWorld()
        {
            var data = new SaveData { seed = seed };
            foreach (var pair in edits) data.edits.Add(new BlockEdit(pair.Key,pair.Value));
            File.WriteAllText(SavePath, JsonUtility.ToJson(data,true));
            Debug.Log("World saved: " + SavePath);
        }

        public void LoadWorld()
        {
            if (!File.Exists(SavePath)) return;
            var data = JsonUtility.FromJson<SaveData>(File.ReadAllText(SavePath));
            if (data == null) return;
            foreach(var go in blocks.Values) if(go) Destroy(go);
            blocks.Clear(); edits.Clear();
            foreach(var e in data.edits) edits[e.position] = e.type;
            seed = data.seed;
            foreach(var c in chunks.Values) if(c) Destroy(c);
            chunks.Clear();
            GenerateWorld();
        }
    }
}
