using UnityEngine;

namespace Blocklands
{
    public class GameHUD : MonoBehaviour
    {
        VoxelWorld world;
        PlayerController player;
        string[] slots = { "GRASS", "DIRT", "STONE", "SAND", "WOOD" };
        GUIStyle buttonStyle, labelStyle, titleStyle;
        float health=100f, hunger=100f;

        void Start()
        {
            world=FindObjectOfType<VoxelWorld>();
            player=FindObjectOfType<PlayerController>();
        }

        void OnGUI()
        {
            if(buttonStyle==null)
            {
                buttonStyle=new GUIStyle(GUI.skin.button) { fontSize=Mathf.Max(14,Screen.width/48), fontStyle=FontStyle.Bold };
                labelStyle=new GUIStyle(GUI.skin.label) { fontSize=Mathf.Max(15,Screen.width/48), normal={textColor=Color.white} };
                titleStyle=new GUIStyle(labelStyle) { fontSize=Mathf.Max(19,Screen.width/36), fontStyle=FontStyle.Bold };
            }
            float s=Screen.width, h=Screen.height;
            GUI.color=new Color(.04f,.07f,.09f,.72f);
            GUI.Box(new Rect(12,12,250,82),"");
            GUI.color=Color.white;
            GUI.Label(new Rect(24,18,230,30),"BLOCKLANDS",titleStyle);
            GUI.Label(new Rect(24,48,230,25),"❤ "+Mathf.RoundToInt(health)+"    FOOD "+Mathf.RoundToInt(hunger),labelStyle);

            // Crosshair
            GUI.Label(new Rect(s*.5f-10,h*.5f-18,30,35),"+",titleStyle);

            float bw=Mathf.Clamp(s*.105f,72,118), bh=Mathf.Clamp(h*.085f,48,76);
            Rect breakRect=new Rect(s-bw-18,h*.53f,bw,bh);
            Rect placeRect=new Rect(s-bw-18,h*.53f+bh+10,bw,bh);
            if(GUI.Button(breakRect,"BREAK",buttonStyle) && world && player) world.BreakBlock(new Ray(player.playerCamera.transform.position,player.playerCamera.transform.forward));
            if(GUI.Button(placeRect,"PLACE",buttonStyle) && world && player) world.PlaceBlock(new Ray(player.playerCamera.transform.position,player.playerCamera.transform.forward));

            float slotW=Mathf.Clamp(s*.14f,62,100);
            float total=slotW*slots.Length+8*(slots.Length-1);
            float start=(s-total)*.5f;
            for(int i=0;i<slots.Length;i++)
            {
                Rect r=new Rect(start+i*(slotW+8),h-bh-18,slotW,bh);
                GUI.color=(world && world.SelectedBlock==i)?new Color(.9f,.72f,.25f,1):new Color(.08f,.12f,.14f,.88f);
                if(GUI.Button(r,slots[i],buttonStyle) && world) world.SelectedBlock=i;
            }
            GUI.color=Color.white;
            if(GUI.Button(new Rect(14,h-94,90,38),"SAVE",buttonStyle) && world) world.SaveWorld();
            if(GUI.Button(new Rect(14,h-50,90,38),"LOAD",buttonStyle) && world) world.LoadWorld();
            GUI.Label(new Rect(s*.28f,18,s*.55f,28),"Drag right side to look • left side to move",labelStyle);
        }
    }
}
