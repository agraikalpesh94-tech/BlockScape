BLOCKLANDS — Android voxel sandbox prototype
============================================

What this is
------------
This is a REAL Unity C# project source ZIP for a small, playable voxel sandbox prototype.
It is NOT an APK yet. I have not compiled or tested it in Unity in this environment, so I will
not pretend an APK exists. The project builds a simple procedural block world, first-person
movement, touch controls, block breaking/placing, a hotbar, basic HUD, day/night lighting,
and local save/load of the explored block edits.

This is a starter prototype, not the full feature list yet. It does not currently include
full Minecraft-scale terrain, polished art, crafting, animals, caves/minerals, multiplayer,
or advanced water/weather.

Project version
---------------
Unity 6 (6000.0 LTS line) recommended. The scripts use built-in Unity components and no
paid assets or third-party packages.

Important phone-only limitation
-------------------------------
Unity's editor is not available as a normal full project-building app on Android phones.
You can keep this ZIP on your phone, but compiling a native APK requires a build machine or
a cloud build service. Unity Build Automation can build Android projects in the cloud, but
it normally requires a Unity account, a source-control repository, and dashboard setup.
Official docs: https://docs.unity.com/en-us/build-automation

What is inside
--------------
Assets/Blocklands/Scripts/VoxelWorld.cs       Procedural chunk world and block interaction
Assets/Blocklands/Scripts/PlayerController.cs First-person movement and mobile touch input
Assets/Blocklands/Scripts/GameHUD.cs          Touch UI, hotbar, HUD, save/load buttons
Assets/Blocklands/Scripts/DayNightCycle.cs    Simple day/night lighting
Assets/Blocklands/Editor/ProjectSetup.cs      Creates a scene and Android build settings
ProjectSettings/ProjectVersion.txt            Unity editor version marker

How to build it when a cloud build setup is available
-----------------------------------------------------
1. Upload the unzipped project to a Git repository (GitHub or Unity Version Control).
2. In Unity Dashboard, open DevOps > Build Automation and connect that repository.
3. Create an Android build configuration. Choose APK rather than App Bundle if you want a
   directly installable APK.
4. Start a build, then download the APK from the build history if it succeeds.
5. On your Android phone, open the downloaded APK and follow Android's install prompt.

The cloud service setup is not one-click and may require account/repository configuration.
Do not install APKs from unknown sources. Only install a build you trust.

Prototype controls
------------------
Left lower screen: movement joystick (drag).
Right side: drag to look around.
BREAK: remove the block under the crosshair.
PLACE: place the selected block.
Hotbar: tap a slot to select a block.
SAVE / LOAD: save or restore local block edits on the device.

If the scene does not appear automatically
------------------------------------------
Open the project in Unity and choose Tools > Blocklands > Create Prototype Scene.
The editor script also attempts to create the scene automatically after import.
